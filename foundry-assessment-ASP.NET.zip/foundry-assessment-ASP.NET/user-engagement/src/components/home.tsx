import React from "react";

function Home() {
    return (
        <div className="navBar">
            <br />
            <h1>Current Engagments</h1>
            
        </div>
    );
}

export default Home;